<?php
/*
 * util functions
 */

function get_server_name()
{
	$ServerName = strtolower($_SERVER['SERVER_NAME']?$_SERVER['SERVER_NAME']:$_SERVER['HTTP_HOST']); 
	if( strpos($ServerName,'http://') ){   
		return str_replace('http://','',$ServerName);
	}  
	return $ServerName;
}

function get_current_url_basename()
{
	$url = pathinfo($_SERVER['REQUEST_URI']);
	return $url['filename']; 
}

/* create page navigator with Next/Previos bar*/
function page_navigator($total_page, $current_page, $link) {
	$next_page = $current_page >= $total_page ? $total_page: ($current_page+1);
	$prev_page = $current_page <= 1 ? 1: ($current_page-1);
	echo '<div class="pages">
		<label >��<em>'.$current_page.'</em>ҳ/��<span>'.$total_page.'</span>ҳ</label>&nbsp;&nbsp;
		<a href="'.$link.'?page=1">&nbsp;��ҳ&nbsp;</a> 
		<a href="'.$link.'?page='.$prev_page.'">&nbsp;��һҳ&nbsp;</a> 
		<a href="'.$link.'?page='.$next_page.'">&nbsp;��һҳ&nbsp;</a> 
		<a href="'.$link.'?page='.$total_page.'">&nbsp;βҳ&nbsp;</a> </div>';
}
?>