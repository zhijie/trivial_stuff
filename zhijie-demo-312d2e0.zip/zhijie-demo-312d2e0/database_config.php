﻿<?php 
	$db_config["hostname"] = "localhost"; //server address
	$db_config["username"] = "root"; //db username
	$db_config["password"] = "onezeros"; // db password
	$db_config["database"] = "demo"; // db name
	$db_config["charset"] = "utf8";// encoding
	$db_config["pconnect"] = 1;// persistent connection to database
	$db_config["log"] = 1;// whether log 
	$db_config["logfilepath"] = './log/';// path of log file
?>