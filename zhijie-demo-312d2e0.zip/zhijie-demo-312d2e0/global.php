﻿<?php
/*
 * global variables
 */

require_once('database.php');

$domain_name = "localhost/demo";//getServerName();

// url ==> description
$g_url_description = array(
	"index"		=> "网站首页",
	"introduce" => "公司介绍",
	"products"	=> "经营项目",
	"news"		=> "新闻中心",
	"credit"	=> "荣誉资质",
	"recruit"	=> "人才招聘",
	"contact"	=> "联系方式",
	"links"		=> "友情链接"
);

$g_database = new Database;

$g_company_credit = $g_database->get_one("select * from credit;");
$g_company_contact = $g_database->get_one("select * from company_contact_info;");
$g_company_news = $g_database->get_all("select * from news");
$g_company_products = $g_database->get_all("select * from product");
$g_company_product_categories = $g_database->get_all("select * from product_category");
$g_company_jobs = $g_database->get_all("select * from jobs");
$g_company_links = $g_database->get_all("select * from links");
$g_company_users = $g_database->get_all("select * from user_info");
?>