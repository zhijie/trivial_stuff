﻿<td id="main" valign="top">
<div class="main_head">
<div><strong>产品分类</strong></div></div>
<div class="main_body">
<div class="px13 lh18">
<div><span class="f_r"><a class="t" href="products.php">显示全部</a>&nbsp;</span>&nbsp;&nbsp;<strong>我公司经营以下几类产品，请查看： 
</strong></div>
<table cellspacing="3" cellpadding="3" width="98%" align="center">
<tbody>
<?php
$NUM_IN_LINE = 3;
$cate_num = count($g_company_product_categories);
$line_num = ($cate_num + 2)/$NUM_IN_LINE;
for($i =0; $i < $line_num; $i++){
	$part = array_slice($g_company_product_categories,$i * 3,$NUM_IN_LINE);
	echo '<tr>';
	foreach($part as $v) {
		echo '<td width="33%"><a "title="'.$cates_part1['category_title'].'" href="products.php?cateid='.$cates_part1['category_id'].'">'.$cates_part1['category_title'].'</a></td>';
	}
	echo '</tr>';
}
?>
</tbody></div></div>
<div class="main_head">
<div><span class="f_r f_n px12"><strong>以橱窗方式浏览</strong> | <a href="maintaining.php?view=1&amp;typeid=0">以目录方式浏览</a> 
</span><strong>供应产品</strong> </div></div>
<div class="main_body">
<table cellspacing="0" cellpadding="0" width="100%">
<tbody>
<?php
$BLOCKS_PER_LINE = 4;
$LINES_PER_PAGE = 4;
$BLOCKS_PER_PAGE = $BLOCKS_PER_LINE * $LINES_PER_PAGE;

$pages = (count($g_company_products) + $BLOCKS_PER_PAGE - 1) / $BLOCKS_PER_PAGE;
if($viewmode != 1){/* view in blocks*/
	for($p =0; $p < $pages; $p++){
		$page_content = array_slice($g_company_products,$p * $BLOCKS_PER_PAGE,$BLOCKS_PER_PAGE);
		$lines = (count($page_content) + $LINES_PER_PAGE -1)/$LINES_PER_PAGE;
		for($l =0; $l < $lines; $l++){	
			echo '<tr align="middle">';
			$line_content = array_slice($page_content,$l * $BLOCKS_PER_LINE,$BLOCKS_PER_LINE);
			foreach($line_content as $block){
				echo '<td height="180" valign="top" width="25%">'.
				'<div class="thumb" onmouseover="this.className=\'thumb thumb_on\';" onmouseout="this.className=\'thumb\';">'.
				'<a href="products.php?productid='.$block['product_id'].
				'"><img alt="'.$block['product_title'].'" src="'.$block['image_thumb_1'].'" width="100" height="100"></a> '.
				'<div><a href="products.php?productid='.$block['product_id'].'">'.$block['product_title'].'</a></div></div>';
				echo '</td>';
			}
			echo '</tr>';
		}
	}
}else {/* view in list mode */

}
?>

<?
// page navigator
page_navigator($pages,$current_page,'products.php');
?>

</tbody></div>
</td>