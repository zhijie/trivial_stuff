﻿<div class="m">
<div id="menu" class="menu">
<ul>

<?php
$current_page = get_current_url_basename();
foreach ($g_url_description as $index => $value) {
	$li_class = $current_page == $index ? "menu_on" : "menu_li";
    echo '<li class="'.$li_class.'"><a href="./'.$index.'.php"><span>'.$g_url_description[$index] .'</span></a></li>';
}
?>

</ul></div></div>