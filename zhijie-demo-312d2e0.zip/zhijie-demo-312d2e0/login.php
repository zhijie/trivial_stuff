﻿<?
	require_once('global.php');
	
    session_start(); // starting session
    
	if (isset($_POST['username']) && isset($_POST['password'])){
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		$db_password;
		foreach($g_company_users as $u){
			if($u['name'] == $username){
				$db_password = $u['password_md5'];
				break;
			}
		}
		if(empty($db_password)){	
			echo '<h1>user does not exit</h1>';
		}else if($db_password != $password){
			echo '<h1>user or password is wrong</h1>';
		}else{
			// login success
			$_SESSION['username'] = $username;
			$_SESSION['password'] = $password;
			header("Location: admin.php");
			exit;
		}
	}
?>
<form method="post">
Username: <input type="text" name="username"><br>
Password: <input type="password" name="password"><br>
<input type="submit" value="Submit">
</form>
