﻿<td id="main" valign="top">
<div class="main_head">
<div><strong>采购清单</strong></div></div>
<div class="main_body">
<div class="px13 lh18">
<table cellspacing="3" cellpadding="3" width="98%" align="center"></table></div>
<div class="pages"><label title="共0条">第<em>1</em>页/共<span>0</span>页</label>&nbsp;&nbsp;<a href="link/index.php?page=1">&nbsp;首页&nbsp;</a> 
<input id="destoon_previous" value="link/index.php?page=0" type="hidden"><a href="link/index.php?page=0">&nbsp;上一页&nbsp;</a> 
<a href="link/index.php?page=1">&nbsp;下一页&nbsp;</a><input id="destoon_next" value="link/index.php?page=1" type="hidden"> <a href="link/index.php?page=0">&nbsp;尾页&nbsp;</a> 
<input onkeydown="if(event.keyCode==13 &amp;&amp; this.value) {window.location.href='link/index.php?page={destoon_page}'.replace(/\{destoon_page\}/, this.value);return false;}" id="destoon_pageno" class="pages_inp" value="1" type="text"> <input class="pages_btn" onclick="if(Dd('destoon_pageno').value&gt;0)window.location.href='link/index.php?page={destoon_page}'.replace(/\{destoon_page\}/, Dd('destoon_pageno').value);" value="GO" type="button"></div></div></td>