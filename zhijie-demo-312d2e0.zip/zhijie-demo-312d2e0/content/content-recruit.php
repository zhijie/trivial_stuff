﻿<td id="main" valign="top">
<div class="main_head">
<div><strong>人才招聘</strong></div></div>
<div class="main_body">
<table cellspacing="1" cellpadding="2" width="100%" align="center">
<tbody>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1314">融资专员 经理 
	（1名） 业务员（若干名）</a></td>
  <td align="middle">&nbsp;融资部&nbsp;</td>
  <td align="middle">&nbsp;若干&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-11-09</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1313">开玻璃师傅</a></td>
  <td align="middle">&nbsp;装潢部&nbsp;</td>
  <td align="middle">&nbsp;5人&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-11-09</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1312">铝窗安装师傅</a></td>
  <td align="middle">&nbsp;装修部&nbsp;</td>
  <td align="middle">&nbsp;若干&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-11-09</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1311">人力资源部经理助理 
	未婚</a></td>
  <td align="middle">&nbsp;人力资源&nbsp;</td>
  <td align="middle">&nbsp;1人&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-11-09</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1310">值班人员 
	40岁以上，退伍军人优先</a></td>
  <td align="middle">&nbsp;&nbsp;</td>
  <td align="middle">&nbsp;1人&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-11-09</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1195">前台接待 
	（身高160cm以上，五官端正）1 名</a></td>
  <td align="middle">&nbsp;&nbsp;</td>
  <td align="middle">&nbsp;1人&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-10-20</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1194">装修工人（室内外装修，熟手优先） 
	若干名</a></td>
  <td align="middle">&nbsp;&nbsp;</td>
  <td align="middle">&nbsp;若干&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-10-20</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1193">建材销售部（经理1名 
	销售员（限女性）若干名）、 文 员（未婚） 若干名</a></td>
  <td align="middle">&nbsp;&nbsp;</td>
  <td align="middle">&nbsp;若干&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-10-20</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1192">工程师、常务副总经理、副 
	总 经 理、前期开发部经理、市场开发部经理、项目部经理、董事长秘书（未婚）</a></td>
  <td align="middle">&nbsp;&nbsp;</td>
  <td align="middle">&nbsp;2人&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-10-20</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=1191"> 报建员1名 
	、总工程师1名</a></td>
  <td align="middle">&nbsp;&nbsp;</td>
  <td align="middle">&nbsp;1人&nbsp;</td>
  <td class="f_gray px11" width="80" align="middle">2011-10-20</td></tr></tbody></table>
<div class="pages"><label title="共10条">第<em>1</em>页/共<span>1</span>页</label>&nbsp;&nbsp;<a href="maintaining.php?page=1">&nbsp;首页&nbsp;</a> 
<input id="destoon_previous" value="maintaining.php?page=1" type="hidden"><a href="maintaining.php?page=1">&nbsp;上一页&nbsp;</a> 
<a href="maintaining.php?page=1">&nbsp;下一页&nbsp;</a><input id="destoon_next" value="maintaining.php?page=1" type="hidden"> <a href="maintaining.php?page=1">&nbsp;尾页&nbsp;</a> 
<input onkeydown="if(event.keyCode==13 &amp;&amp; this.value) {window.location.href='maintaining.php?page={destoon_page}'.replace(/\{destoon_page\}/, this.value);return false;}" id="destoon_pageno" class="pages_inp" value="1" type="text"> <input class="pages_btn" onclick="if(Dd('destoon_pageno').value&gt;0)window.location.href='maintaining.php?page={destoon_page}'.replace(/\{destoon_page\}/, Dd('destoon_pageno').value);" value="GO" type="button"></div></div></td>