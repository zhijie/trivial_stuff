﻿<td id="main" valign="top">
<div class="main_head">
<div><strong>新闻中心</strong></div></div>
<div class="main_body">
<table cellspacing="1" cellpadding="2" width="100%" align="center">
<tbody>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=29169">“梦幻夜景”说明</a></td>
  <td class="f_gray px11" width="80" align="middle">2011-11-10</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=29168">方案说明 
	</a></td>
  <td class="f_gray px11" width="80" align="middle">2011-11-10</td></tr>
<tr>
  <td class="px13" height="25">·<a href="maintaining.php?itemid=29167">图纸目录 
	</a></td>
  <td class="f_gray px11" width="80" align="middle">2011-11-10</td></tr></tbody></table>
<div class="pages"><label title="共3条">第<em>1</em>页/共<span>1</span>页</label>&nbsp;&nbsp;<a href="maintaining.php?page=1">&nbsp;首页&nbsp;</a> 
<input id="destoon_previous" value="maintaining.php?page=1" type="hidden"><a href="maintaining.php?page=1">&nbsp;上一页&nbsp;</a> 
<a href="maintaining.php?page=1">&nbsp;下一页&nbsp;</a><input id="destoon_next" value="maintaining.php?page=1" type="hidden"> <a href="maintaining.php?page=1">&nbsp;尾页&nbsp;</a> 
<input onkeydown="if(event.keyCode==13 &amp;&amp; this.value) {window.location.href='maintaining.php?page={destoon_page}'.replace(/\{destoon_page\}/, this.value);return false;}" id="destoon_pageno" class="pages_inp" value="1" type="text"> <input class="pages_btn" onclick="if(Dd('destoon_pageno').value&gt;0)window.location.href='maintaining.php?page={destoon_page}'.replace(/\{destoon_page\}/, Dd('destoon_pageno').value);" value="GO" type="button"></div></div>
<script type="text/javascript">
try {Dd('type_0').innerHTML = '<strong>'+Dd('name_0').innerHTML+'</strong>';}catch (e){}
</script>
</td>