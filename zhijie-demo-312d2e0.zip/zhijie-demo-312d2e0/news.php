﻿<?php include('header.php') ?>

<div class="m">
<table cellspacing="0" cellpadding="0" width="100%">
  <tbody><tr>
<?php include('sidebar.php') ?>
<?php include('content/content-news.php') ?>
  </tr></tbody>
</table></div>

<?php include('footer.php') ?>

</html>
