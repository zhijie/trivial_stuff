﻿<td id="main" valign="top">
<div class="main_head">
<div><span class="f_r"><a href="products.php"><img title="更多" src="image/more.gif"></a></span><strong>推荐产品</strong></div></div>
<div class="main_body">
<div style="HEIGHT: 180px; OVERFLOW: hidden" id="elite">
<table cellspacing="0" cellpadding="0" width="100%">
<tbody>
<tr align="middle">
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301262"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/09-00-27-54-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301262">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301261"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/09-00-12-98-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301261">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301260"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-59-52-19-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301260">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301259"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-59-38-58-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301259">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301258"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-59-22-52-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301258">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td></tr>
<tr align="middle">
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301256"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-59-07-75-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301256">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301255"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-58-54-55-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301255">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301254"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-58-41-61-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301254">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301253"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-57-45-11-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301253">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301252"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-57-28-13-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301252">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td></tr></tbody></table></div></div>

<div class="main_head">
<div><span class="f_r"><a href="introduce.php"><img title="更多" src="image/more.gif"></a></span><strong>公司介绍</strong></div></div>
<div class="main_body">
<div class="lh18 px13 pd10"><img style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; PADDING-BOTTOM: 5px; MARGIN: 5px 0px 5px 10px; PADDING-LEFT: 5px; PADDING-RIGHT: 5px; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid; PADDING-TOP: 5px" align="right" src="http://www.chinapyp.com/file/upload/201111/10/08-45-48-13-102890.jpg"> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<?php echo $g_company_credit['introduction'] ?>
[<a class="t" href="introduce.php">详细介绍</a>] 
<div class="c_b"></div></div></div>
<div class="main_head">
<div><span class="f_r"><a href="products.php"><img title="更多" src="image/more.gif"></a></span><strong>最新供应</strong></div></div>
      
	  
<div class="main_body">
<table cellspacing="0" cellpadding="0" width="100%">
<tbody>
<tr align="middle">
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301262"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/09-00-27-54-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301262">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301261"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/09-00-12-98-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301261">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301260"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-59-52-19-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301260">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301259"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-59-38-58-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301259">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301258"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-59-22-52-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301258">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td></tr>
<tr align="middle">
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301256"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-59-07-75-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301256">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301255"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-58-54-55-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301255">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301254"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-58-41-61-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301254">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301253"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-57-45-11-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301253">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td>
  <td height="180" valign="top" width="20%">
	<div class="thumb" onmouseover="this.className='thumb thumb_on';" onmouseout="this.className='thumb';"><a href="maintaining.php?itemid=301252"><img alt="明耀实业" src="http://www.chinapyp.com/file/upload/201111/10/08-57-28-13-102890.jpg.thumb.jpg" width="100" height="100"></a> 
	<div><a title="明耀实业" href="maintaining.php?itemid=301252">明耀实业</a></div><!--<p>2011-11-10</p>--></div></td></tr></tbody>
</table></div>



	  </td>