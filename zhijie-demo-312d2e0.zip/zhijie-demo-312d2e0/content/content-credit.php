﻿<td id="main" valign="top">
<div class="main_head">
<div><strong>公司档案</strong></div></div>
<div class="main_body">
<div class="px13 lh18">
<table cellspacing="1" cellpadding="3" width="98%" align="center">
<tbody>
<tr>
  <td class="f_b" width="90">公司名称：</td>
  <td width="260"><?php echo $g_company_credit['company_name']?></td>
  <td class="f_b" width="90">公司类型：</td>
  <td width="260"><?php echo $g_company_credit['company_type']?></td></tr>
<tr>
  <td class="f_b">所 在 地：</td>
  <td><?php echo $g_company_credit['company_address']?></td>
  <td class="f_b">公司规模：</td>
  <td><?php echo $g_company_credit['company_size']?></td></tr>
<tr>
  <td class="f_b">注册资本：</td>
  <td><?php echo $g_company_credit['registered_capital']?></td>
  <td class="f_b">注册年份：</td>
  <td><?php echo $g_company_credit['registered_year']?></td></tr></tbody></table>
<table cellspacing="1" cellpadding="3" width="98%" align="center">

<!--
<tr>
  <td class="f_b">资料认证：</td>
  <td>&nbsp;<img align="absMiddle" src="http://www.chinapyp.com/skin/default/image/check_right.gif"> 
	企业资料通过认证</td></tr>
-->
<tr>
  <td class="f_b">经营范围：</td>
  <td><?php echo $g_company_credit['business_scope']?></td></tr>
<tr>
  <td class="f_b">主营行业：</td>
  <td><?php echo $g_company_credit['main_industry']?></td></tr>

</table></div></div></td>
