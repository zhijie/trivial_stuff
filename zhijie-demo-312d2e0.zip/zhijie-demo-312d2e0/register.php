﻿<?php
require_once('global.php');

if(isset($_POST['username']) && isset($_POST['password'])){
	$name = $_POST['username'];
	$password = $_POST['password'];
	$exists = $g_database->get_one('select * from user_info where name = "'.$name.'"');
	if(!empty($exists)){
		echo '<p1>user exists</p1>';
	}else {
		$userinfo = array('name' => $name,'password_md5' => md5($password));
		if($g_database->insert('user_info',$userinfo)){
			echo '<p1>success to register</p1>';
		}else {
			echo '<p1>failed to register</p1>';
		}
	}
	
}
?>
<form method="post">
Username: <input type="text" name="username"><br>
Password: <input type="password" name="password"><br>
<input type="submit" value="Registe">
</form>