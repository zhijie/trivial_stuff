﻿<td id="main" valign="top">
<div class="main_head">
<div><strong>联系方式</strong></div></div>
<div class="main_body">
<div class="px13 lh18">
<table cellspacing="3" cellpadding="3" width="98%" align="center">
<tbody>
<tr>
  <td width="100">公司名称：</td>
  <td><?php echo $g_company_credit['company_name']?></td></tr>
<tr>
  <td>公司地址：</td>
  <td><?php echo $g_company_credit['company_address']?></td></tr>
<tr>
  <td>邮政编码：</td>
  <td><?php echo $g_company_contact['zip_code']?></td></tr>
<tr>
  <td>公司电话：</td>
  <td><?php echo $g_company_contact['telephone']?></td></tr>
<tr>
  <td>公司传真：</td>
  <td><?php echo $g_company_contact['fax']?></td></tr>
<tr>
  <td>公司网址：</td>
  <td><a href="" target="_blank"></a></td></tr>
<tr>
  <td>联 系 人：</td>
  <td><?php echo $g_company_contact['contact_person']?></td></tr>
</tbody></table></div></div>
<div class="main_head">
<div><strong>在线留言</strong><a name="guestbook"></a></div></div>
<div class="main_body"><iframe style="WIDTH: 98%; HEIGHT: 488px" id="fra" src="http://www.chinapyp.com/company/home.php?action=message&amp;job=guestbook&amp;template=homepage&amp;skin=default&amp;username=hnmysy&amp;sign=9ED67D3B65D61B6A655474E2DBF20438" frameborder="0" name="fra" scrolling="no"></iframe></div></td>
