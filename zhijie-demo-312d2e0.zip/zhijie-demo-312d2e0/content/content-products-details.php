﻿<td id="main" valign="top">
      <div id="pos_show" class="dsn">您当前的位置：<a href="http://hnmysy.chinapyp.com/">首页</a> ? <a href="http://hnmysy.chinapyp.com/sell/">供应产品</a> ? 明耀实业</div>
      <div class="main_head">
      <div><strong>明耀实业</strong></div></div>
      <div class="main_body">
      <table width="100%" align="center">
        <tbody>
        <tr>
          <td valign="top" width="270">
            <div class="album">
            <table cellspacing="0" cellpadding="0" width="100%">
              <tbody>
              <tr align="middle">
                <td valign="top" width="250">
                  <div><span id="abm" title="点击图片查看大图"><img src="http://www.chinapyp.com/file/upload/201111/10/09-00-14-38-102890.jpg.middle.jpg" onload="if(this.width&gt;240){this.width=240;}" onclick="PAlbum(this);" onmouseover="SAlbum(this.src);" onmouseout="HAlbum();" id="DIMG"></span></div></td></tr>
              <tr>
                <td><img id="t_0" class="ab_im" onmouseover="if(this.src.indexOf('nopic60.gif')==-1)Album(0, 'http://www.chinapyp.com/file/upload/201111/10/09-00-12-98-102890.jpg.middle.jpg');" src="http://www.chinapyp.com/file/upload/201111/10/09-00-12-98-102890.jpg.thumb.jpg" width="60" height="60"><img id="t_1" class="ab_on" onmouseover="if(this.src.indexOf('nopic60.gif')==-1)Album(1, 'http://www.chinapyp.com/file/upload/201111/10/09-00-14-38-102890.jpg.middle.jpg');" src="http://www.chinapyp.com/file/upload/201111/10/09-00-14-38-102890.jpg.thumb.jpg" width="60" height="60"><img id="t_2" class="ab_im" onmouseover="if(this.src.indexOf('nopic60.gif')==-1)Album(2, 'http://www.chinapyp.com/file/upload/201111/10/09-00-17-50-102890.jpg.middle.jpg');" src="http://www.chinapyp.com/file/upload/201111/10/09-00-17-50-102890.jpg.thumb.jpg" width="60" height="60"></td></tr>
              <tr align="middle">
                <td onclick="PAlbum(Dd('DIMG'));" height="30"><img align="absMiddle" src="http://www.chinapyp.com/skin/default/image/ico_zoom.gif" width="16" height="16"> 点击图片查看大图</td></tr></tbody></table></div></td>
          <td valign="top">
            <div style="display: none; " id="imgshow"><img src="http://www.chinapyp.com/file/upload/201111/10/09-00-12-98-102890.jpg" onload="if(this.width&lt;240){HAlbum();}else if(this.width&gt;400){this.width=400;}"></div>
            <table cellspacing="4" cellpadding="4" width="100%">
              <tbody>
              <tr>
                <td class="f_dblue" width="80">产 品：</td>
                <td><span id="hits" class="f_r">浏览次数：22</span><strong>明耀实业</strong>&nbsp;</td></tr>
              <tr>
                <td class="f_dblue">单 价：</td>
                <td class="f_b f_orange">面议&nbsp;</td></tr>
              <tr>
                <td class="f_dblue">最小起订量：</td>
                <td class="f_b f_orange">&nbsp;</td></tr>
              <tr>
                <td class="f_dblue">供货总量：</td>
                <td class="f_b f_orange"></td></tr>
              <tr>
                <td class="f_dblue">发货期限：</td>
                <td>自买家付款之日起 <span class="f_b f_orange">3</span> 天内发货</td></tr>
              <tr><!--<td class="f_dblue">更新日期：</td>
<td>2011-11-10&nbsp;&nbsp;有效期至：长期有效</td>--></tr>
              <tr>
                <td class="f_dblue">&nbsp;</td>
                <td><a href="http://hnmysy.chinapyp.com/maintaining.php?itemid=301261#message"><img alt="询价" src="http://www.chinapyp.com/skin/default/image/btn_inquiry.gif"></a></td></tr></tbody></table>
            <script type="text/javascript">
document.write('<br/><br/><center><a href="http://www.chinapyp.com/company/home.php?action=prev&itemid=301261&username=hnmysy" class="t">&#171;上一个产品</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.chinapyp.com/company/home.php?action=next&itemid=301261&username=hnmysy" class="t">下一个产品&#187;</a></center>');
</script><br><br><center><a href="http://www.chinapyp.com/company/home.php?action=prev&amp;itemid=301261&amp;username=hnmysy" class="t">?上一个产品</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.chinapyp.com/company/home.php?action=next&amp;itemid=301261&amp;username=hnmysy" class="t">下一个产品?</a></center>
          </td></tr></tbody></table></div>
      <div class="main_head">
      <div><strong>详细信息</strong></div></div>
      <div class="main_body">
      <div id="content" class="content"><span style="FONT-SIZE: 14px"><!--[if !mso]>
      <STYLE>.shape {
	BEHAVIOR: url(#default#VML)
}
v:textbox {
	DISPLAY: none
}
</STYLE>
<![endif]-->&lt;!--[if !ppt]--&gt;&lt;!--[endif]--&gt; </span>
      <div style="tab-interval: 1.0468in" class="O">
      <div><span style="FONT-SIZE: 14px"><span style="POSITION: absolute; LEFT: -3.31%">?</span></span>主营：楼梯扶手、栏杆扶手、地板砖、各种灯饰、天花吊顶、橱柜、地毯、铝材、墙纸建材工具刀等多个项目的销售。 
      <br><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </span>公司本着“品质第一，诚信专业，严谨务实，开拓创新”的企业精神，始终将客户的利益放在首位，向更多客户提供高品质的产品和最优秀的服务，力求让每一位选择海南明耀的客户真正享受到实惠。<br><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      </span>海南明耀实业有限公司愿与广大客户一起锐意创新，努力开拓，不断提高自我，翱翔世界！！</div></div></div></div>
      <div class="main_head">
      <div><strong><span id="message_title">询价单</span><a name="message"></a></strong></div></div>
      <div class="main_body"><iframe style="WIDTH: 98%; HEIGHT: 488px" id="fra" src="http://www.chinapyp.com/company/home.php?action=message&amp;job=inquiry&amp;&amp;itemid=301261&amp;template=homepage&amp;skin=default&amp;title=%E6%98%8E%E6%9C%88%E5%AE%9E%E4%B8%9A&amp;username=hnmysy&amp;sign=A25D14869A22B5BEBC958DF9BDD440DA" frameborder="0" name="fra" scrolling="no"></iframe></div>
      <div id="comment_div">
      <div class="main_head">
      <div><span class="f_r px12">共<span id="comment_count">0</span>条&nbsp;&nbsp;</span><strong><span id="message_title">相关评论</span></strong></div></div>
      <div class="main_body"><iframe style="WIDTH: 100%" id="destoon_comment" src="http://www.chinapyp.com/extend/comment.php?mid=5&amp;itemid=301261" frameborder="0" scrolling="no"></iframe></div></div>
      <script type="text/javascript">
try {Dd('type_0').style.backgroundColor = '#F1F1F1';}catch (e){}
</script>

      <script type="text/javascript">
var content_id = 'content';
var img_max_width = 550;
</script>

      <script type="text/javascript" src="http://www.chinapyp.com/file/script/content.js"></script>
    </td>