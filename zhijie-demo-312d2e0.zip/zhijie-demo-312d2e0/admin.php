﻿<?php
	require_once('global.php');
	
	// checking if user is not authenticated
	session_start(); // starting session
	
	$is_authorized = false;
    if (!isset($_SESSION['username']) || !isset($_SESSION['password'])){
	}else {
		$username = $_SESSION['username'];
		$password = $_SESSION['password'];
		$db_password;
		foreach($g_company_users as $u){
			if($u['name'] == $username){
				$db_password = $u['password_md5'];
				break;
			}
		}
		if($db_password == $password){
			$is_authorized = true;
		}
	}
	if($is_authorized){
	}else {
		header('Location: login.php');
		exit;
	}
?>

<html xmlns="http://www.w3.org/1999/xhtml">

<?php include('header.php') ?>


<!-- show side navigator -->
<?php
	$item2show = 'introduce';
	if(isset($_GET['item'])) {
		$item2show = $_GET['item'];
		if($item2show == 'index' || !array_key_exists($item2show, $g_url_description)){
			$item2show = 'introduce';
		}
	}
?>

<!-- kindeditor scripts-->
<link rel="stylesheet" href="./kindeditor/themes/default/default.css" />
<link rel="stylesheet" href="./kindeditor/plugins/code/prettify.css" />
<script charset="utf-8" src="./kindeditor/kindeditor.js"></script>
<script charset="utf-8" src="./kindeditor/lang/zh_CN.js"></script>
<script charset="utf-8" src="./kindeditor/plugins/code/prettify.js"></script>
<script>
	KindEditor.ready(function(K) {
		var editor1 = K.create('textarea[name="richcontent"]', {
			cssPath : './kindeditor/plugins/code/prettify.css',
			uploadJson : './kindeditor/php/upload_json.php',
			fileManagerJson : './kindeditor/php/file_manager_json.php',
			allowFileManager : true,
			afterCreate : function() {
				var self = this;
				K.ctrl(document, 13, function() {
					self.sync();
					K('form[name=editor]')[0].submit();
				});
				K.ctrl(self.edit.doc, 13, function() {
					self.sync();
					K('form[name=editor]')[0].submit();
				});
			}
		});
		prettyPrint();
	});
</script>

<div class="m">
<table cellspacing="0" cellpadding="0" width="100%">
  <tbody><tr>
<!-- side bar -->
<div id="nav">
    <td id="side" valign="top" width="200">
      <div class="side_head">
      <div><strong>内容管理</strong></div></div>
	  <div class="side_body"><ul>
	  <?php
		foreach($g_url_description as $k => $v) {
			if($k == 'index'){
				continue;
			}
			echo '<li><a title="'.$v.'" href="./admin.php?item='.$k.'">'.$v.'</a></li>';
		}
	  ?>
	  </ul></div>
	</td>
    <td id="split" width="10"></td>
</div> <!-- end #nav -->
<!-- content -->
<td id="main" valign="top">
<div class="main_head">
<div><strong><?php echo $g_url_description[$item2show] ?></strong></div></div>
<div class="main_body">
<?php
// show content acoording seleted item
	switch($item2show){
		case "introduce":
	$htmlData = '';
	if (!empty($_POST['richcontent'])) {
		if (get_magic_quotes_gpc()) {
			$htmlData = stripslashes($_POST['richcontent']);
		} else {
			$htmlData = $_POST['richcontent'];
		}
	}
	if($htmlData != ''){ //means user updated data, so update database
		$g_database->update('credit',array('introduction' => $htmlData));
	}else { // get content from database, which will be shown in editor
		$arr = $g_database->get_one('select * from credit');
		$htmlData = $arr['introduction'];
	}
	echo '<form name="editor" method="post" action="admin.php?item='.$item2show.'">
	<textarea name="richcontent" style="width:700px;height:500px;visibility:hidden;">';
	echo htmlspecialchars($htmlData);
	echo '</textarea><br />	<input type="submit" name="button" value="保存" /></form>';
			break;
		case "products":
			break;
		case "news":
	$htmlData = '';
	if (!empty($_POST['richcontent'])) {
		if (get_magic_quotes_gpc()) {
			$htmlData = stripslashes($_POST['richcontent']);
		} else {
			$htmlData = $_POST['richcontent'];
		}
	}
	if($htmlData != ''){ //means user updated data, so update database
		$g_database->update('news',array('content' => $htmlData));
	}else { // get content from database, which will be shown in editor
		$arr = $g_database->get_one('select * from credit');
		$htmlData = $arr['introduction'];
	}
	echo '<form name="editor" method="post" action="admin.php?item='.$item2show.'">
	<input type="text" name="news_title" style="width:700px"/><br />
	<textarea name="richcontent" style="width:700px;height:200px;visibility:hidden;">';
	echo htmlspecialchars($htmlData);
	echo '</textarea><br />	<input type="submit" name="button" value="保存" /></form>';
			break;
		// case "credit":
			// echo '<form name="editor" method="post" action="admin.php?item='.$item2show.'">';
			// echo 
			// foreach ($g_company_credit as $key => $value){
				
			// }
			// break;
		case "recruit":
			break;
		// case "contact":
			// break;
		case "links":
			break;
	}
?>
</div></td>

  </tr></tbody>
</table></div>

<?php include('footer.php') ?>

</html>