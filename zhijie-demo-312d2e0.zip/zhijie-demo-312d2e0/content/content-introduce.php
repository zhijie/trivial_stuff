﻿<td id="main" valign="top">
  <div class="main_head">
  <div><strong>公司介绍</strong></div></div>
  <div class="main_body">
  <div class="lh18 px13">
  <table cellspacing="3" cellpadding="3" width="98%" align="center">
	<tbody>
	<tr>
	  <td><img style="BORDER-BOTTOM: #c0c0c0 1px solid; BORDER-LEFT: #c0c0c0 1px solid; PADDING-BOTTOM: 5px; MARGIN: 5px 0px 5px 10px; PADDING-LEFT: 5px; PADDING-RIGHT: 5px; BORDER-TOP: #c0c0c0 1px solid; BORDER-RIGHT: #c0c0c0 1px solid; PADDING-TOP: 5px" align="right" src="http://www.chinapyp.com/file/upload/201111/10/08-45-48-13-102890.jpg"><span style="FONT-SIZE: 16px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="FONT-FAMILY: 楷体_GB2312"><?php echo $g_company_credit['introduction'] ?></span></span></td></tr></tbody></table></div></div>
	  
  <div class="main_head">
  <div><strong>公司档案</strong></div></div>
  <div class="main_body">
  <div class="px13 lh18">
  <table cellspacing="1" cellpadding="3" width="98%" align="center">
	<tbody>
	<tr>
	  <td class="f_b" width="90">公司名称：</td>
	  <td width="260"><?php echo $g_company_credit['company_name']?></td>
	  <td class="f_b" width="90">公司类型：</td>
	  <td width="260"><?php echo $g_company_credit['company_type']?></td></tr>
	<tr>
	  <td class="f_b">所 在 地：</td>
	  <td><?php echo $g_company_credit['company_address']?></td>
	  <td class="f_b">公司规模：</td>
	  <td><?php echo $g_company_credit['company_size']?></td></tr>
	<tr>
	  <td class="f_b">注册资本：</td>
	  <td><?php echo $g_company_credit['registered_capital']?></td>
	  <td class="f_b">注册年份：</td>
	  <td><?php echo $g_company_credit['registered_year']?></td></tr></tbody></table>
  <table cellspacing="1" cellpadding="3" width="98%" align="center">
	<tbody>
<!--
	<tr>
	  <td class="f_b">资料认证：</td>
	  <td>&nbsp;<img align="absMiddle" src="http://www.chinapyp.com/skin/default/image/check_right.gif"> 
		企业资料通过认证</td></tr>
-->
<tr>
  <td class="f_b">经营范围：</td>
  <td><?php echo $g_company_credit['business_scope']?></td></tr>
<tr>
  <td class="f_b">主营行业：</td>
  <td><?php echo $g_company_credit['main_industry']?></td></tr>

</table></div></div>
  <div id="comment_div">
  <div class="main_head">
  <div><span class="f_r px12">共<span id="comment_count">0</span>条&nbsp;&nbsp;</span><strong><span id="message_title">相关评论</span></strong></div></div>
  <div class="main_body"><iframe style="WIDTH: 100%" id="destoon_comment" src="http://www.chinapyp.com/extend/comment.php?mid=4&amp;itemid=102890" frameborder="0" scrolling="no"></iframe></div></div></td>
