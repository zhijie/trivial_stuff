<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<?php require_once('functions.php') ?>
<?php require_once('global.php') ?>
<head>
<title><?php echo $g_company_credit['company_name'] ?></title>
<meta content="text/html;charset=utf-8" http-equiv="Content-Type">
<meta name="keywords" content="<?php echo $g_company_credit['company_name'] ?>, <?php echo $g_company_credit['business_scope'] ?>">
<meta name="description" content="<?php echo $g_company_credit['introduction'] ?>">
<meta name="GENERATOR" content="MSHTML 8.00.6001.19222">
<meta name="template" content="homepage">
<link rel="stylesheet" type="text/css" href="css/common.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script type="text/javascript">window.onerror= function(){return true;}</script>
<script type="text/javascript" src="script/homepage.js"></script>
<script type="text/javascript" src="script/lang.js"></script>
</head>

<body>

<div class="m">
<div id="top" class="top">
<a title="<?php echo $g_company_credit['company_name'] ?>" 
	onclick="window.external.addFavorite(this.href, this.title);return false;" 
	href="" rel="sidebar">收藏本页</a> | 
<a onclick="javascript:try{this.style.behavior='url(#default#homepage)';this.setHomePage(location.href);}catch(e){}return false;" href="">设为主页</a> | 
<a href="javascript:Go(DTTour);">随便看看</a></div>
</div>

<div class="m">
<div class="head">
<div style="MARGIN: 20px 0px 0px 5px">
<font style="MARGIN: 32px 0px 5px 10px; FONT-FAMILY: 黑体; COLOR: #000000; FONT-SIZE: 26px"><?php echo $g_company_credit['company_name'] ?></font>
<br><font style="MARGIN: 0px 0px 0px 10px; COLOR: #000000; FONT-SIZE: 16px"><?php echo $g_company_credit['business_scope'] ?></font> 
</div></div></div>

<?php require_once('nav.php') ?>
<div class="m">
<div class="banner"><img src="image/header.jpg" width="100%"> </div></div>

<div class="m">
<div id="pos" class="pos">
<span class="f_r">
<script type="text/javascript">show_date();</script>
</span>
<span id="position">您当前的位置：<a href="">首页</a> » 欢迎光临</span>
</div></div>

</div> <!-- end #header -->

