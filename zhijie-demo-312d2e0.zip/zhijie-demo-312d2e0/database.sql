﻿drop database demo;
create database demo
       character set utf8
       default character set utf8
       collate utf8_general_ci
       default collate utf8_general_ci ;
use demo;
set names 'utf8';
/*VB*XT51cTKqp*/
create table product_category
(
	category_id		int not null auto_increment,
	category_title	nvarchar(50) not null,
	primary key (category_id)
);

/* information about a single product */
create table product
(
	product_id		int not null auto_increment,
	category_id		int not null default '0',
	product_title	nvarchar(50) not null,
	price			nvarchar(256) ,
	moq				nvarchar(256) , /*minimun_order_quantity*/
	delivery_date	nvarchar(256) ,
	image_1			nvarchar(256) ,
	image_2			nvarchar(256) ,
	image_3			nvarchar(256) ,
	image_thumb_1	nvarchar(256) ,
	image_thumb_2	nvarchar(256) ,
	image_thumb_3	nvarchar(256) ,
	description		nvarchar(256) not null,
	view_count		bigint default '0' not null,/* automatically record view count*/
	primary key(product_id),
	foreign key(category_id) references product_category(category_id) on delete cascade on update cascade
);

create table news
(
	news_id 	int not null auto_increment,
	title		nvarchar(256) not null,
	content		longtext not null,
	publish_date	timestamp not null default current_timestamp,
	view_count	bigint default '0' not null,/* automatically record view count*/
	primary key(news_id)
);

create table links
(
	link_id 	int not null auto_increment,
	description	nvarchar(256) not null,
	url			nvarchar(500) not null,
	primary key(link_id)
);

create table jobs
(
	job_id 		int not null auto_increment,
	title		nvarchar(256) not null,
	detail		text,
	job_number	nvarchar(20) not null,
	publish_date	timestamp not null default current_timestamp,
	expire_date		timestamp ,
	primary key (job_id)
);

create table company_contact_info
(
	zip_code		varchar(10) ,
	telephone		varchar(20) ,
	fax				varchar(20) ,
	contact_person  nvarchar(50)
);

create table credit
(
	introduction		longtext,
	company_name		nvarchar(256),	
	company_address		nvarchar(256),	
	registered_capital	nvarchar(50),
	registered_year		nvarchar(50),
	company_type		nvarchar(10),
	company_size		nvarchar(50),
	business_scope		nvarchar(256),	
	main_industry		nvarchar(256)
);
create table user_info
(
	user_id		int not null auto_increment,
	name	nvarchar(50),
	password_md5 varchar(32),
	email		nvarchar(50),
	primary key(user_id)
);

/* for tables who have only one record, insert one first*/
insert into credit values ('    海南明耀建筑装饰工程有限公司是经海南省三亚市工商管理局批准的集房地产开发、实业投资、基础设施投资、建筑装饰设施投资、建筑装饰工程、建筑劳务服务、钢结构工程设计、安装、防水补漏工程、房屋加固维修、市政道路工程、土石方工程、园林绿化工程、水电安装工程、智能化工程、房屋建筑工程以及弱电工程于一体的专业化建筑装饰工程企业。 
公司于2012年5月在三亚市注册成立，注册资金1000万元，现有各类专业技术人员21人，其中高级设计师2人、高级工程师2人、高级经济师1人、高级会计师1人、中级以上各类专业技术人员10人，有项目经理资格证的工程负责人3人，有2名以沿海技术工人为骨干的施工队伍，并有精良的技术设备和机械设备。
   公司成立以来始终坚持“敬业、求实、创新、争先”的企业精神，遵循“诚信、严谨、科学、守法”的执业准则，格守“质量第一、信誉至上、信用合作服务社会”为宗指，竭诚为业主提供高质量、高标准的服务。
    海南明耀建筑装饰工程有限公司期朌为您的服务，竭诚企望与社会各界合作，共谋发展！','海南明耀建筑装饰工程有限公司','海南省三亚市商品街东方大厦505',
	'1000万人民币','2011','个体经营',
	'','主营房地产开发、事业投资、基础设施投资、基础装饰设施投资、钢结构工程设计、安装防水漏补工程、房屋加固维修、市政道路工程、土石方工程、园林绿化工程、水电安装工程、智能化工程、房屋建筑工程','商务服务、酒店、广告、人才');
insert into company_contact_info values ('572200','0898-38221688','0898-38889288','徐明计（先生）');
/*insert into product_category(category_title) values ();
*/