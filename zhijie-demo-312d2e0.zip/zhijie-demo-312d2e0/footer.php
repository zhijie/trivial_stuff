﻿</body>
<div id="footer">
<div class="m">
<div id="foot" class="foot">
<div>
<?php
foreach ($g_url_description as $index => $value) {
    echo '<a href="./'.$index.'.php"><span>'.$g_url_description[$index] .'</span></a> &nbsp;|&nbsp;';
}
?>

<a href="login.php">管理入口</a> 
<br>&copy;2012 <?php echo $g_company_credit['company_name'] ?> 版权所有&nbsp;&nbsp;&nbsp;&nbsp;访问量：2103</div></div></div>

</div> <!-- end #footer -->