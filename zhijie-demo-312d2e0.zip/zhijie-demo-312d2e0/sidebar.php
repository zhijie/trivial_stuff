﻿<div id="nav">
	  <script type="text/javascript" src="script/marquee.js"></script>
      <script type="text/javascript">window.onload = function() {new dmarquee(180, 15, 2000, 'elite');}/* FIX IE6 */</script>

    <td id="side" valign="top" width="200">
      <div class="side_head">
      <div><strong>网站公告</strong></div></div>
      <div class="side_body">
      <div style="PADDING-BOTTOM: 0px; LINE-HEIGHT: 180%; PADDING-LEFT: 5px; PADDING-RIGHT: 5px; HEIGHT: 100px; OVERFLOW: hidden; PADDING-TOP: 0px">
      <marquee onmouseover="this.stop();" onmouseout="this.start();" direction="up" height="100" behavior="scroll" scrollamount="1" scrolldelay="85"><span style="FONT-SIZE: 14px"><span>&nbsp;&nbsp;&nbsp;&nbsp; 
      </span><span><?php echo $g_company_credit['introduction']?></span></span></marquee></div></div>
      <div class="side_head">
      <div><span class="f_r"><a href="news.php"><img title="更多" src="image/more.gif"></a></span><strong>新闻中心</strong></div></div>
      <div class="side_body">
      <ul>
<?php
$news = array_slice($g_company_news,0,5);
foreach($news as $v){
	echo '<li><a title="'.$v['title'].' ('.$v['publish_date'].')" href="news.php?newsid="'.$v['news_id'].'">'.$v['title'].'</a></li>';
}
?>
	  </ul></div>
	  <div class="side_head">
      <div><span class="f_r"><a href="products.php"><img title="更多" src="image/more.gif"></a></span><strong>经营项目</strong></div></div>
      <div class="side_body">
      <ul>
<?php
foreach($g_company_product_categories as $cate){
	echo '<li><a title="'.$cate['category_title'].'" href="products.php?cateid='.$cate['category_id'].'">'.$cate['category_title'].'</a></li>';
}

?>
	  </ul></div>
      <div class="side_head">
      <div><strong>站内搜索</strong></div></div>
      <div class="side_body">
      <form onsubmit="return check_kw();" action="maintaining.php"><input value="search" type="hidden" name="action"> <input value="hnmysy" type="hidden" name="homepage"> 
      <input id="kw" class="inp" onfocus="if(this.value=='输入关键词')this.value='';" value="输入关键词" size="25" type="text" name="kw"> 
      <div style="PADDING-BOTTOM: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; PADDING-TOP: 10px"><select name="file"> <option selected="" value="sell">供应产品</option><option value="buy">采购清单</option><option value="news">新闻中心</option><option value="credit">荣誉资质</option><option value="job">人才招聘</option><option value="photo">友情链接</option></select>&nbsp; <input class="sbm" value=" 搜 索 " type="submit"> </div></form></div>

      <div class="side_head">
      <div><span class="f_r"><a href="links.php"><img title="更多" src="image/more.gif"></a></span><strong>友情链接</strong></div></div>
      <div class="side_body">
      <ul>
<?php
$links = array_slice($g_company_links,0,5);
foreach($links as $v){
	echo '<li><a title="'.$v['description'].'" href="'.$v['url'].'" target="_blank">'.$cate['description'].'</a></li>';
}
?>
	  </ul></div>
	</td>
    <td id="split" width="10"></td>
</div> <!-- end #nav -->