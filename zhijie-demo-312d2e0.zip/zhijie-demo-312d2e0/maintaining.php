﻿<?php include('header.php') ?>

<div class="m">
<table cellspacing="0" cellpadding="0" width="100%">
  <tbody><tr>
<?php include('sidebar.php') ?>

<td id="main" valign="top">
<div class="main_head">
<div><strong>致歉</strong></div></div>
<div class="main_body">
<div align="center">
谢谢您的关注，网站正在维护中，欢迎下次光临</div>
</div></td>

  </tr></tbody>
</table></div>

<?php include('footer.php') ?>

</html>